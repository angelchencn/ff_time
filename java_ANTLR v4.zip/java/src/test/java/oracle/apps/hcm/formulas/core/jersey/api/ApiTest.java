package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.config.*;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Mirrors test_api.py (7 tests) + test_api_extended.py (7 tests).
 * HTTP integration tests using Jersey Test Framework.
 */
class ApiTest {

    private static JerseyTest jerseyTest;

    @BeforeAll
    static void setUp() throws Exception {
        jerseyTest = new JerseyTest() {
            @Override
            protected jakarta.ws.rs.core.Application configure() {
                forceSet(TestProperties.CONTAINER_PORT, "0");
                return new JerseyConfig();
            }
        };
        jerseyTest.setUp();
    }

    @AfterAll
    static void tearDown() throws Exception {
        jerseyTest.tearDown();
    }

    // ── test_api.py ─────────────────────────────────────────────────────────

    @Test
    void validateValidFormula() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code", "DEFAULT FOR hours IS 0\nRETURN hours")));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals(true, data.get("valid"));
    }

    @Test
    void validateInvalidFormula() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code", "IF hours > THEN")));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals(false, data.get("valid"));
    }

    @Test
    void simulateFormula() {
        var resp = jerseyTest.target("/api/simulate")
                .request()
                .post(Entity.json(Map.of(
                        "code", "DEFAULT FOR hours IS 0\not_pay = hours * 1.5\nRETURN ot_pay",
                        "input_data", Map.of("hours", 10)
                )));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals("SUCCESS", data.get("status"));
    }

    @Test
    void dbiList() {
        var resp = jerseyTest.target("/api/dbi")
                .queryParam("limit", "3")
                .request()
                .get();
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertNotNull(data.get("total"));
    }

    @Test
    void dbiSearch() {
        var resp = jerseyTest.target("/api/dbi")
                .queryParam("search", "hours")
                .queryParam("limit", "5")
                .request()
                .get();
        assertEquals(200, resp.getStatus());
    }

    @Test
    void validateMissingCode() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code", "")));
        assertEquals(400, resp.getStatus());
    }

    @Test
    void simulateMissingFields() {
        var resp = jerseyTest.target("/api/simulate")
                .request()
                .post(Entity.json(Map.of()));
        assertEquals(400, resp.getStatus());
    }

    // ── test_api_extended.py ────────────────────────────────────────────────

    @Test
    void formulaTypesEndpoint() {
        var resp = jerseyTest.target("/api/formula-types")
                .request()
                .get();
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(java.util.List.class);
        assertTrue(data.size() >= 9);
    }

    @Test
    void validateWithConcatOperator() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code", "msg = 'Hello' || ' World'\nRETURN msg")));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals(true, data.get("valid"));
    }

    @Test
    void validateWithGetContext() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code", "ffs_id = GET_CONTEXT(HWM_FFS_ID, 0)\nRETURN ffs_id")));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals(true, data.get("valid"));
    }

    @Test
    void validateWithWasNotDefaulted() {
        var resp = jerseyTest.target("/api/validate")
                .request()
                .post(Entity.json(Map.of("code",
                        "DEFAULT FOR x IS 0\nIF x WAS NOT DEFAULTED THEN\n  y = x\nELSE\n  y = 0\nENDIF\nRETURN y")));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals(true, data.get("valid"));
    }

    @Test
    void simulateWithConcat() {
        var resp = jerseyTest.target("/api/simulate")
                .request()
                .post(Entity.json(Map.of(
                        "code", "DEFAULT FOR name IS 'World'\nresult = 'Hello ' || name\nRETURN result",
                        "input_data", Map.of("name", "Oracle")
                )));
        assertEquals(200, resp.getStatus());
        @SuppressWarnings("unchecked")
        var data = resp.readEntity(Map.class);
        assertEquals("SUCCESS", data.get("status"));
        @SuppressWarnings("unchecked")
        var output = (Map<String, Object>) data.get("output_data");
        assertEquals("Hello Oracle", output.get("result"));
    }

    @Test
    void healthEndpoint() {
        var resp = jerseyTest.target("/api/health")
                .request()
                .get();
        assertEquals(200, resp.getStatus());
    }
}
