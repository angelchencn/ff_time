package oracle.apps.hcm.formulas.core.jersey.api;

import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.Test;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HealthResourceTest {

    private final HealthResource resource = new HealthResource();

    @Test
    void healthEndpointReturnsHealthy() {
        Response response = resource.health();
        assertEquals(200, response.getStatus());

        @SuppressWarnings("unchecked")
        var body = (Map<String, String>) response.getEntity();
        assertEquals("healthy", body.get("status"));
    }
}
