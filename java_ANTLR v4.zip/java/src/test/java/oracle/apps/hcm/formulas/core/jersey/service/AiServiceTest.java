package oracle.apps.hcm.formulas.core.jersey.service;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Mirrors test_session_fixes.py TestFixDefaultTypes (9 tests)
 * + test_ai_service.py system prompt check (1 test).
 */
class AiServiceTest {

    @Test
    void systemPromptContainsKeywords() {
        assertTrue(AiService.SYSTEM_PROMPT.contains("Fast Formula"));
        assertTrue(AiService.SYSTEM_PROMPT.contains("DEFAULT"));
    }

    @Nested
    class FixDefaultTypesTests {
        @Test
        void nameVariableGetsStringDefault() {
            assertEquals("DEFAULT FOR BASE_TASK_NAME IS ' '",
                    AiService.fixDefaultTypes("DEFAULT FOR BASE_TASK_NAME IS 0"));
        }

        @Test
        void counterVariableStaysNumeric() {
            assertEquals("DEFAULT FOR REPEAT_COUNTER IS 0",
                    AiService.fixDefaultTypes("DEFAULT FOR REPEAT_COUNTER IS 0"));
        }

        @Test
        void dateVariableGetsDateDefault() {
            assertEquals("DEFAULT FOR EFFECTIVE_DATE IS '01-JAN-0001'(DATE)",
                    AiService.fixDefaultTypes("DEFAULT FOR EFFECTIVE_DATE IS 0"));
        }

        @Test
        void statusVariableGetsStringDefault() {
            assertEquals("DEFAULT FOR ROLLBACK_STATUS IS ' '",
                    AiService.fixDefaultTypes("DEFAULT FOR ROLLBACK_STATUS IS 0"));
        }

        @Test
        void typeVariableGetsStringDefault() {
            assertEquals("DEFAULT FOR PROCESS_TYPE IS ' '",
                    AiService.fixDefaultTypes("DEFAULT FOR PROCESS_TYPE IS 0"));
        }

        @Test
        void alreadyCorrectStringNotChanged() {
            assertEquals("DEFAULT FOR BASE_TASK_NAME IS ' '",
                    AiService.fixDefaultTypes("DEFAULT FOR BASE_TASK_NAME IS ' '"));
        }

        @Test
        void alreadyCorrectNumberNotChanged() {
            assertEquals("DEFAULT FOR HOURS_WORKED IS 0",
                    AiService.fixDefaultTypes("DEFAULT FOR HOURS_WORKED IS 0"));
        }

        @Test
        void multiline() {
            String code = "DEFAULT FOR BASE_TASK_NAME IS 0\n"
                    + "DEFAULT FOR REPEAT_COUNTER IS 0\n"
                    + "DEFAULT FOR EFFECTIVE_DATE IS 0\n"
                    + "DEFAULT FOR PROCESS_TYPE IS 0";
            String fixed = AiService.fixDefaultTypes(code);
            String[] lines = fixed.split("\n");
            assertTrue(lines[0].contains("IS ' '"));         // NAME → string
            assertTrue(lines[1].contains("IS 0"));            // COUNTER → number
            assertTrue(lines[2].contains("(DATE)"));          // DATE → date
            assertTrue(lines[3].contains("IS ' '"));          // TYPE → string
        }

        @Test
        void idVariableStaysNumeric() {
            assertEquals("DEFAULT FOR PAYROLL_RUN_ID IS 0",
                    AiService.fixDefaultTypes("DEFAULT FOR PAYROLL_RUN_ID IS 0"));
        }
    }
}
