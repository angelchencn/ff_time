package oracle.apps.hcm.formulas.core.jersey.parser;

import oracle.apps.hcm.formulas.core.jersey.parser.AstNodes.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Mirrors test_parser.py (3 tests).
 */
class FFParserTest {

    @Test
    void parseSimpleFormula() {
        String code = """
                DEFAULT FOR hours IS 0
                INPUT IS rate
                ot_pay = hours * rate
                RETURN ot_pay
                """;
        var result = FFParser.parse(code);
        assertNotNull(result.program());
        assertTrue(result.diagnostics().isEmpty());
        var stmts = result.program().statements();
        assertEquals(4, stmts.size());
        assertInstanceOf(DefaultDecl.class, stmts.get(0));
        assertEquals("hours", ((DefaultDecl) stmts.get(0)).name());
    }

    @Test
    void parseIfElse() {
        String code = """
                IF hours > 40 THEN
                    ot_hours = hours - 40
                ELSE
                    ot_hours = 0
                ENDIF
                RETURN ot_hours
                """;
        var result = FFParser.parse(code);
        assertNotNull(result.program());
        assertInstanceOf(IfStatement.class, result.program().statements().get(0));
        assertInstanceOf(ReturnStatement.class, result.program().statements().get(1));
    }

    @Test
    void parseSyntaxErrorReturnsDiagnostics() {
        var result = FFParser.parse("IF hours > THEN");
        assertFalse(result.diagnostics().isEmpty());
        assertEquals("error", result.diagnostics().get(0).severity());
    }
}
