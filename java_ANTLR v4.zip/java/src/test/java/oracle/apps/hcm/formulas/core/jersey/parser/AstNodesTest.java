package oracle.apps.hcm.formulas.core.jersey.parser;

import oracle.apps.hcm.formulas.core.jersey.parser.AstNodes.*;

import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AstNodesTest {

    @Test
    void recordsAreImmutable() {
        var lit = new AstNodes.NumberLiteral(42.0);
        assertEquals(42.0, lit.value());

        var id = new AstNodes.Identifier("hours_worked");
        assertEquals("hours_worked", id.name());
    }

    @Test
    void programHoldsStatements() {
        var input = new AstNodes.InputDecl(List.of("hours"));
        var output = new AstNodes.OutputDecl(List.of("pay"));
        var program = new AstNodes.Program(List.of(input, output));

        assertEquals(2, program.statements().size());
        assertInstanceOf(AstNodes.InputDecl.class, program.statements().get(0));
    }

    @Test
    void sealedInterfacePatternMatching() {
        AstNodes node = new AstNodes.StringLiteral("hello");

        String result = switch (node) {
            case AstNodes.StringLiteral s -> s.value();
            case AstNodes.NumberLiteral n -> String.valueOf(n.value());
            default -> "unknown";
        };

        assertEquals("hello", result);
    }
}
