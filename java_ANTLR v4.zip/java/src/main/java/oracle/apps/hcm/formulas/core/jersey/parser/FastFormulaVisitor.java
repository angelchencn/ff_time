// Generated from src/main/java/oracle/apps/hcm/formulas/core/jersey/parser/FastFormula.g4 by ANTLR 4.13.1
package oracle.apps.hcm.formulas.core.jersey.parser;
import groovyjarjarantlr4.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link FastFormulaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface FastFormulaVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(FastFormulaParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(FastFormulaParser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#aliasStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAliasStmt(FastFormulaParser.AliasStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defaultDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefaultDecl(FastFormulaParser.DefaultDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code defaultDataValueDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefaultDataValueDecl(FastFormulaParser.DefaultDataValueDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code inputDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputDecl(FastFormulaParser.InputDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code inputsDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputsDecl(FastFormulaParser.InputsDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code outputDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutputDecl(FastFormulaParser.OutputDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code outputsDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutputsDecl(FastFormulaParser.OutputsDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code localDecl}
	 * labeled alternative in {@link FastFormulaParser#varDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocalDecl(FastFormulaParser.LocalDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#dataType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDataType(FastFormulaParser.DataTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#nameList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameList(FastFormulaParser.NameListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nameAssignment}
	 * labeled alternative in {@link FastFormulaParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameAssignment(FastFormulaParser.NameAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code quotedAssignment}
	 * labeled alternative in {@link FastFormulaParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuotedAssignment(FastFormulaParser.QuotedAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#arrayAssignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAssignment(FastFormulaParser.ArrayAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#callFormulaStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallFormulaStmt(FastFormulaParser.CallFormulaStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#callFormulaArgs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallFormulaArgs(FastFormulaParser.CallFormulaArgsContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#callFormulaArg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallFormulaArg(FastFormulaParser.CallFormulaArgContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#changeContextsStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChangeContextsStmt(FastFormulaParser.ChangeContextsStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#contextAssignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContextAssignment(FastFormulaParser.ContextAssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#executeStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExecuteStmt(FastFormulaParser.ExecuteStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#bareFuncCallStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBareFuncCallStmt(FastFormulaParser.BareFuncCallStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#ifStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStmt(FastFormulaParser.IfStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#thenBody}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitThenBody(FastFormulaParser.ThenBodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#elseBody}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseBody(FastFormulaParser.ElseBodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#elsifClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElsifClause(FastFormulaParser.ElsifClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#whileStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStmt(FastFormulaParser.WhileStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#loopBody}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoopBody(FastFormulaParser.LoopBodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#forStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForStmt(FastFormulaParser.ForStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#cursorDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursorDecl(FastFormulaParser.CursorDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#selectStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelectStmt(FastFormulaParser.SelectStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#selectItems}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelectItems(FastFormulaParser.SelectItemsContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#selectItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelectItem(FastFormulaParser.SelectItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#orderItems}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderItems(FastFormulaParser.OrderItemsContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#orderItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrderItem(FastFormulaParser.OrderItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#forCursorStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForCursorStmt(FastFormulaParser.ForCursorStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exitWhen}
	 * labeled alternative in {@link FastFormulaParser#exitStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExitWhen(FastFormulaParser.ExitWhenContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exitPlain}
	 * labeled alternative in {@link FastFormulaParser#exitStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExitPlain(FastFormulaParser.ExitPlainContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#blockStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockStmt(FastFormulaParser.BlockStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code returnWithValues}
	 * labeled alternative in {@link FastFormulaParser#returnStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnWithValues(FastFormulaParser.ReturnWithValuesContext ctx);
	/**
	 * Visit a parse tree produced by the {@code emptyReturn}
	 * labeled alternative in {@link FastFormulaParser#returnStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyReturn(FastFormulaParser.EmptyReturnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code isNotNull}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsNotNull(FastFormulaParser.IsNotNullContext ctx);
	/**
	 * Visit a parse tree produced by the {@code inExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInExpr(FastFormulaParser.InExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code wasNotDefaulted}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWasNotDefaulted(FastFormulaParser.WasNotDefaultedContext ctx);
	/**
	 * Visit a parse tree produced by the {@code wasNotFound}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWasNotFound(FastFormulaParser.WasNotFoundContext ctx);
	/**
	 * Visit a parse tree produced by the {@code atomExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtomExpr(FastFormulaParser.AtomExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code orExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrExpr(FastFormulaParser.OrExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comparisonExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExpr(FastFormulaParser.ComparisonExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code wasFound}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWasFound(FastFormulaParser.WasFoundContext ctx);
	/**
	 * Visit a parse tree produced by the {@code betweenExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetweenExpr(FastFormulaParser.BetweenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code concatExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatExpr(FastFormulaParser.ConcatExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notLikeExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotLikeExpr(FastFormulaParser.NotLikeExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotExpr(FastFormulaParser.NotExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notInExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotInExpr(FastFormulaParser.NotInExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code addExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddExpr(FastFormulaParser.AddExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code wasDefaulted}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWasDefaulted(FastFormulaParser.WasDefaultedContext ctx);
	/**
	 * Visit a parse tree produced by the {@code negExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegExpr(FastFormulaParser.NegExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code isNull}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsNull(FastFormulaParser.IsNullContext ctx);
	/**
	 * Visit a parse tree produced by the {@code likeExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLikeExpr(FastFormulaParser.LikeExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mulExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulExpr(FastFormulaParser.MulExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notBetweenExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotBetweenExpr(FastFormulaParser.NotBetweenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code andExpr}
	 * labeled alternative in {@link FastFormulaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAndExpr(FastFormulaParser.AndExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#compOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompOp(FastFormulaParser.CompOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#addOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddOp(FastFormulaParser.AddOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#mulOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulOp(FastFormulaParser.MulOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numberLiteral}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberLiteral(FastFormulaParser.NumberLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code typedStringLiteral}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypedStringLiteral(FastFormulaParser.TypedStringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code singleStringLiteral}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleStringLiteral(FastFormulaParser.SingleStringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code methodCall}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodCall(FastFormulaParser.MethodCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayAccess}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAccess(FastFormulaParser.ArrayAccessContext ctx);
	/**
	 * Visit a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncCall(FastFormulaParser.FuncCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code varRef}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarRef(FastFormulaParser.VarRefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code quotedVarRef}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuotedVarRef(FastFormulaParser.QuotedVarRefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link FastFormulaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenExpr(FastFormulaParser.ParenExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link FastFormulaParser#exprList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprList(FastFormulaParser.ExprListContext ctx);
}