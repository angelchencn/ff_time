package oracle.apps.hcm.formulas.core.jersey;

import oracle.apps.hcm.formulas.core.jersey.config.*;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;

import java.net.URI;

public class App {

    private static final String BASE_URI = "http://0.0.0.0:8000/";

    public static void main(String[] args) throws Exception {
        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(
                URI.create(BASE_URI), new JerseyConfig());

        System.out.println("FF Time server started at " + BASE_URI + "api/");
        System.out.println("Press Ctrl+C to stop...");
        Thread.currentThread().join();
    }
}
