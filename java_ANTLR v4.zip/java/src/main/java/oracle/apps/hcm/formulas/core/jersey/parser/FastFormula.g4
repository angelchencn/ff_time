// Oracle Fast Formula Grammar — ANTLR4
// Converted from grammar.lark
// Reference: Oracle FastFormula User Guide

grammar FastFormula;

// ===================== Parser Rules =====================

program
    : statement+ EOF
    ;

statement
    : aliasStmt SEMI?
    | varDecl SEMI?
    | assignment SEMI?
    | arrayAssignment SEMI?
    | ifStmt SEMI?
    | whileStmt SEMI?
    | forStmt SEMI?
    | cursorDecl SEMI?
    | forCursorStmt SEMI?
    | returnStmt SEMI?
    | exitStmt SEMI?
    | callFormulaStmt SEMI?
    | changeContextsStmt SEMI?
    | executeStmt SEMI?
    | bareFuncCallStmt SEMI?
    | blockStmt SEMI?
    ;

// --- Alias ---
aliasStmt
    : ALIAS NAME AS NAME
    ;

// --- Variable Declarations ---
varDecl
    : DEFAULT FOR NAME dataType? IS expr dataType?           # defaultDecl
    | DEFAULT_DATA_VALUE FOR NAME IS expr dataType?          # defaultDataValueDecl
    | INPUT IS NAME                                          # inputDecl
    | INPUTS ARE nameList                                    # inputsDecl
    | OUTPUT IS NAME                                         # outputDecl
    | OUTPUTS ARE nameList                                   # outputsDecl
    | LOCAL NAME dataType?                                   # localDecl
    ;

dataType
    : '(' ( NUMBER_TYPE | TEXT_TYPE | DATE_TYPE ) ')'
    ;

nameList
    : NAME dataType? ( ',' NAME dataType? )*
    ;

// --- Assignment ---
assignment
    : NAME '=' expr                    # nameAssignment
    | QUOTED_NAME '=' expr             # quotedAssignment
    ;

// --- Array Assignment ---
arrayAssignment
    : NAME '[' expr ']' '=' expr
    ;

// --- CALL_FORMULA ---
callFormulaStmt
    : CALL_FORMULA '(' callFormulaArgs ')'
    ;

callFormulaArgs
    : callFormulaArg ( ',' callFormulaArg )*
    ;

callFormulaArg
    : expr ( ( '>' | '<' ) SINGLE_STRING ( DEFAULT expr )? )?
    ;

// --- CHANGE_CONTEXTS ---
changeContextsStmt
    : CHANGE_CONTEXTS '(' contextAssignment ( ',' contextAssignment )* ')'
    ;

contextAssignment
    : NAME '=' expr
    ;

// --- EXECUTE ---
executeStmt
    : EXECUTE '(' SINGLE_STRING ')'
    ;

// --- Bare function call as statement ---
bareFuncCallStmt
    : NAME '(' exprList? ')'
    ;

// --- IF / THEN / ELSIF / ELSE / END IF ---
ifStmt
    : IF expr THEN thenBody elsifClause* ( ELSE elseBody )? ENDIF?
    ;

thenBody
    : '(' statement+ ')'
    | statement+
    ;

elseBody
    : '(' statement+ ')'
    | statement+
    ;

elsifClause
    : ELSIF expr THEN ( '(' statement+ ')' | statement+ )
    ;

// --- WHILE / LOOP / END LOOP ---
whileStmt
    : WHILE expr LOOP loopBody ENDLOOP
    ;

loopBody
    : '(' statement+ ')'
    | statement+
    ;

// --- FOR range loop: FOR var IN start..end LOOP ... END LOOP ---
forStmt
    : FOR NAME IN expr DOTDOT expr LOOP loopBody ENDLOOP
    ;

// --- CURSOR declaration ---
cursorDecl
    : CURSOR NAME IS selectStmt
    ;

selectStmt
    : SELECT selectItems FROM NAME ( WHERE expr )? ( ORDER BY orderItems )?
    ;

selectItems
    : selectItem ( ',' selectItem )*
    ;

selectItem
    : expr ( AS NAME )?
    ;

orderItems
    : orderItem ( ',' orderItem )*
    ;

orderItem
    : expr ( ASC | DESC )?
    ;

// --- FOR cursor loop: FOR rec IN cursor_name LOOP ... END LOOP ---
forCursorStmt
    : FOR NAME IN NAME LOOP loopBody ENDLOOP
    ;

// --- EXIT / EXIT WHEN ---
exitStmt
    : EXIT WHEN expr                     # exitWhen
    | EXIT                               # exitPlain
    ;

// --- Block statement: ( stmt1 stmt2 ... ) ---
blockStmt
    : '(' statement+ ')'
    ;

// --- RETURN ---
returnStmt
    : RETURN expr ( ',' expr )*        # returnWithValues
    | RETURN                            # emptyReturn
    ;

// --- Expressions (precedence from low to high) ---
expr
    : expr OR expr                                   # orExpr
    | expr AND expr                                  # andExpr
    | NOT expr                                       # notExpr
    | expr WAS NOT DEFAULTED                         # wasNotDefaulted
    | expr WAS DEFAULTED                             # wasDefaulted
    | expr WAS NOT FOUND                             # wasNotFound
    | expr WAS FOUND                                 # wasFound
    | expr IS NOT NULL_KW                            # isNotNull
    | expr IS NULL_KW                                # isNull
    | expr LIKE expr                                 # likeExpr
    | expr NOT LIKE expr                             # notLikeExpr
    | expr BETWEEN expr AND expr                     # betweenExpr
    | expr NOT BETWEEN expr AND expr                 # notBetweenExpr
    | expr IN '(' exprList ')'                       # inExpr
    | expr NOT IN '(' exprList ')'                   # notInExpr
    | expr compOp expr                               # comparisonExpr
    | expr CONCAT expr                               # concatExpr
    | expr addOp expr                                # addExpr
    | expr mulOp expr                                # mulExpr
    | '-' expr                                       # negExpr
    | atom                                           # atomExpr
    ;

compOp
    : '=' | '!=' | '<>' | '><' | '<' | '>' | '<=' | '>=' | '=>' | '=<'
    ;

addOp
    : '+' | '-'
    ;

mulOp
    : '*' | '/'
    ;

atom
    : NUMBER                                         # numberLiteral
    | SINGLE_STRING dataType                         # typedStringLiteral
    | SINGLE_STRING                                  # singleStringLiteral
    | NAME '.' NAME '(' exprList? ')'                # methodCall
    | NAME '[' expr ']'                              # arrayAccess
    | NAME '(' exprList? ')'                         # funcCall
    | NAME                                           # varRef
    | QUOTED_NAME                                    # quotedVarRef
    | '(' expr ')'                                   # parenExpr
    ;

exprList
    : expr ( ',' expr )*
    ;


// ===================== Lexer Rules =====================

// --- Keywords (case-insensitive) ---
ALIAS              : A L I A S ;
AS                 : A S ;
DEFAULT_DATA_VALUE : D E F A U L T '_' D A T A '_' V A L U E ;
DEFAULT            : D E F A U L T ;
DEFAULTED          : D E F A U L T E D ;
FOUND              : F O U N D ;
FOR                : F O R ;
INPUT              : I N P U T ;
INPUTS             : I N P U T S ;
OUTPUT             : O U T P U T ;
OUTPUTS            : O U T P U T S ;
LOCAL              : L O C A L ;
IS                 : I S ;
ARE                : A R E ;
IF                 : I F ;
THEN               : T H E N ;
ELSIF              : E L S I F ;
ELSE               : E L S E ;
ENDIF              : E N D WS_INLINE? I F ;
WHILE              : W H I L E ;
LOOP               : L O O P ;
ENDLOOP            : E N D WS_INLINE? L O O P ;
RETURN             : R E T U R N ;
EXIT               : E X I T ;
WHEN               : W H E N ;
EXECUTE            : E X E C U T E ;
CALL_FORMULA       : C A L L '_' F O R M U L A ;
CHANGE_CONTEXTS    : C H A N G E '_' C O N T E X T S ;
OR                 : O R ;
AND                : A N D ;
NOT                : N O T ;
WAS                : W A S ;
LIKE               : L I K E ;
BETWEEN            : B E T W E E N ;
IN                 : I N ;
USING              : U S I N G ;
NULL_KW            : N U L L ;
CURSOR             : C U R S O R ;
SELECT             : S E L E C T ;
FROM               : F R O M ;
WHERE              : W H E R E ;
ORDER              : O R D E R ;
BY                 : B Y ;
ASC                : A S C ;
DESC               : D E S C ;

NUMBER_TYPE        : N U M B E R ;
TEXT_TYPE          : T E X T ;
DATE_TYPE          : D A T E ;

// --- Operators ---
CONCAT             : '||' ;
DOTDOT             : '..' ;
SEMI               : ';' ;

// --- Literals ---
NUMBER             : [0-9]+ ('.' [0-9]+)? ;

SINGLE_STRING      : '\'' ( ~['] | '\'\'' )* '\'' ;

// Double-quoted tokens serve as both quoted identifiers and escaped strings.
// ANTLR uses a single lexer rule; the parser context determines the meaning.
QUOTED_NAME        : '"' ( ~["] )+ '"' ;

NAME               : [a-zA-Z_] [a-zA-Z0-9_]* ;

// --- Skip ---
LINE_COMMENT       : '--' ~[\r\n]* -> skip ;
BLOCK_COMMENT      : '/*' .*? '*/' -> skip ;
WS                 : [ \t\r\n]+ -> skip ;

// Internal fragment for ENDIF / ENDLOOP whitespace
fragment WS_INLINE : [ \t]+ ;

// --- Case-insensitive letter fragments ---
fragment A : [aA] ;
fragment B : [bB] ;
fragment C : [cC] ;
fragment D : [dD] ;
fragment E : [eE] ;
fragment F : [fF] ;
fragment G : [gG] ;
fragment H : [hH] ;
fragment I : [iI] ;
fragment J : [jJ] ;
fragment K : [kK] ;
fragment L : [lL] ;
fragment M : [mM] ;
fragment N : [nN] ;
fragment O : [oO] ;
fragment P : [pP] ;
fragment Q : [qQ] ;
fragment R : [rR] ;
fragment S : [sS] ;
fragment T : [tT] ;
fragment U : [uU] ;
fragment V : [vV] ;
fragment W : [wW] ;
fragment X : [xX] ;
fragment Y : [yY] ;
fragment Z : [zZ] ;
