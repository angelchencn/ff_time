package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;

@Path("/debug")
public class DebugResource {

    /** Get all LLM request logs (newest first) */
    @GET
    @Path("/llm-logs")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLogs() {
        return Response.ok(LlmDebugLog.getInstance().getAll()).build();
    }

    /** Get only the latest LLM request */
    @GET
    @Path("/llm-logs/latest")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLatest() {
        return Response.ok(LlmDebugLog.getInstance().getLatest()).build();
    }

    /** Clear all logs */
    @DELETE
    @Path("/llm-logs")
    @Produces(MediaType.APPLICATION_JSON)
    public Response clearLogs() {
        LlmDebugLog.getInstance().clear();
        return Response.ok(Map.of("status", "cleared")).build();
    }
}
