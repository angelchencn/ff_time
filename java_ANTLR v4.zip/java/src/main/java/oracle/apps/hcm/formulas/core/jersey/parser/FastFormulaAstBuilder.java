package oracle.apps.hcm.formulas.core.jersey.parser;

import oracle.apps.hcm.formulas.core.jersey.parser.AstNodes.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ANTLR4 Visitor that converts parse tree into immutable AST nodes.
 * Equivalent to Python's FFTransformer (Lark Transformer).
 *
 * NOTE: This class extends the ANTLR4-generated FastFormulaBaseVisitor.
 * Run `mvn generate-sources` to generate FastFormulaBaseVisitor from the .g4 grammar.
 */
public class FastFormulaAstBuilder extends FastFormulaBaseVisitor<AstNodes> {

    // ── Program ─────────────────────────────────────────────────────────────

    @Override
    public AstNodes visitProgram(FastFormulaParser.ProgramContext ctx) {
        List<AstNodes> statements = new ArrayList<>();
        for (var stmtCtx : ctx.statement()) {
            AstNodes node = visit(stmtCtx);
            // Flatten multi-name declarations into individual nodes
            if (node instanceof InputDecl && ((InputDecl) node).names().size() > 1) {
                InputDecl decl = (InputDecl) node;
                for (String name : decl.names()) {
                    statements.add(new InputDecl(List.of(name)));
                }
            } else if (node instanceof OutputDecl && ((OutputDecl) node).names().size() > 1) {
                OutputDecl decl = (OutputDecl) node;
                for (String name : decl.names()) {
                    statements.add(new OutputDecl(List.of(name)));
                }
            } else {
                statements.add(node);
            }
        }
        return new Program(statements);
    }

    // ── Alias ───────────────────────────────────────────────────────────────

    @Override
    public AstNodes visitAliasStmt(FastFormulaParser.AliasStmtContext ctx) {
        String longName = ctx.NAME(0).getText();
        String shortName = ctx.NAME(1).getText();
        return new AliasDecl(longName, shortName);
    }

    // ── Variable Declarations ───────────────────────────────────────────────

    @Override
    public AstNodes visitDefaultDecl(FastFormulaParser.DefaultDeclContext ctx) {
        String name = ctx.NAME().getText();
        AstNodes value = visit(ctx.expr());
        return new DefaultDecl(name, value);
    }

    @Override
    public AstNodes visitDefaultDataValueDecl(FastFormulaParser.DefaultDataValueDeclContext ctx) {
        String name = ctx.NAME().getText();
        AstNodes value = visit(ctx.expr());
        return new DefaultDataValue(name, value);
    }

    @Override
    public AstNodes visitInputDecl(FastFormulaParser.InputDeclContext ctx) {
        return new InputDecl(List.of(ctx.NAME().getText()));
    }

    @Override
    public AstNodes visitInputsDecl(FastFormulaParser.InputsDeclContext ctx) {
        List<String> names = new ArrayList<>();
        for (var nameToken : ctx.nameList().NAME()) {
            names.add(nameToken.getText());
        }
        return new InputDecl(names);
    }

    @Override
    public AstNodes visitOutputDecl(FastFormulaParser.OutputDeclContext ctx) {
        return new OutputDecl(List.of(ctx.NAME().getText()));
    }

    @Override
    public AstNodes visitOutputsDecl(FastFormulaParser.OutputsDeclContext ctx) {
        List<String> names = new ArrayList<>();
        for (var nameToken : ctx.nameList().NAME()) {
            names.add(nameToken.getText());
        }
        return new OutputDecl(names);
    }

    @Override
    public AstNodes visitLocalDecl(FastFormulaParser.LocalDeclContext ctx) {
        return new LocalDecl(ctx.NAME().getText());
    }

    // ── Assignment ──────────────────────────────────────────────────────────

    @Override
    public AstNodes visitNameAssignment(FastFormulaParser.NameAssignmentContext ctx) {
        String name = ctx.NAME().getText();
        AstNodes value = visit(ctx.expr());
        return new Assignment(name, value);
    }

    @Override
    public AstNodes visitQuotedAssignment(FastFormulaParser.QuotedAssignmentContext ctx) {
        String raw = ctx.QUOTED_NAME().getText();
        String name = raw.substring(1, raw.length() - 1); // strip quotes
        AstNodes value = visit(ctx.expr());
        return new Assignment(name, value);
    }

    @Override
    public AstNodes visitArrayAssignment(FastFormulaParser.ArrayAssignmentContext ctx) {
        String name = ctx.NAME().getText();
        AstNodes index = visit(ctx.expr(0));
        AstNodes value = visit(ctx.expr(1));
        return new ArrayAssignment(name, index, value);
    }

    // ── CALL_FORMULA ────────────────────────────────────────────────────────

    @Override
    public AstNodes visitCallFormulaStmt(FastFormulaParser.CallFormulaStmtContext ctx) {
        List<InParam> inParams = new ArrayList<>();
        List<OutParam> outParams = new ArrayList<>();
        AstNodes formulaNameExpr = null;

        for (var argCtx : ctx.callFormulaArgs().callFormulaArg()) {
            AstNodes expr = visit(argCtx.expr(0));
            if (argCtx.SINGLE_STRING() != null) {
                String paramName = stripQuotes(argCtx.SINGLE_STRING().getText());
                if (argCtx.getText().contains(">")) {
                    String varName = expr instanceof Identifier ? ((Identifier) expr).name() : expr.toString();
                    inParams.add(new InParam(varName, paramName));
                } else {
                    Object defaultVal = argCtx.expr().size() > 1 ? visit(argCtx.expr(1)) : null;
                    String varName = expr instanceof Identifier ? ((Identifier) expr).name() : expr.toString();
                    outParams.add(new OutParam(varName, paramName, defaultVal));
                }
            } else if (formulaNameExpr == null) {
                formulaNameExpr = expr;
            }
        }

        String formulaName = formulaNameExpr instanceof StringLiteral ? ((StringLiteral) formulaNameExpr).value() : "";
        return new CallFormula(formulaName, inParams, outParams);
    }

    // ── CHANGE_CONTEXTS ─────────────────────────────────────────────────────

    @Override
    public AstNodes visitChangeContextsStmt(FastFormulaParser.ChangeContextsStmtContext ctx) {
        Map<String, AstNodes> contexts = new LinkedHashMap<>();
        for (var assignCtx : ctx.contextAssignment()) {
            String name = assignCtx.NAME().getText();
            AstNodes value = visit(assignCtx.expr());
            contexts.put(name, value);
        }
        return new ChangeContexts(contexts);
    }

    // ── EXECUTE ─────────────────────────────────────────────────────────────

    @Override
    public AstNodes visitExecuteStmt(FastFormulaParser.ExecuteStmtContext ctx) {
        return new Execute(stripQuotes(ctx.SINGLE_STRING().getText()));
    }

    // ── Bare function call ──────────────────────────────────────────────────

    @Override
    public AstNodes visitBareFuncCallStmt(FastFormulaParser.BareFuncCallStmtContext ctx) {
        String name = ctx.NAME().getText();
        List<AstNodes> args = visitExprListOrEmpty(ctx.exprList());
        return new FunctionCall(name, args);
    }

    // ── IF / WHILE / RETURN ─────────────────────────────────────────────────

    @Override
    public AstNodes visitIfStmt(FastFormulaParser.IfStmtContext ctx) {
        AstNodes condition = visit(ctx.expr());
        List<AstNodes> thenBody = visitStatementList(ctx.thenBody().statement());

        List<ElsifClause> elsifClauses = new ArrayList<>();
        for (var elsifCtx : ctx.elsifClause()) {
            AstNodes elsifCond = visit(elsifCtx.expr());
            List<AstNodes> elsifBody = visitStatementList(elsifCtx.statement());
            elsifClauses.add(new ElsifClause(elsifCond, elsifBody));
        }

        List<AstNodes> elseBody = ctx.elseBody() != null
                ? visitStatementList(ctx.elseBody().statement())
                : List.of();

        return new IfStatement(condition, thenBody, elsifClauses, elseBody);
    }

    @Override
    public AstNodes visitWhileStmt(FastFormulaParser.WhileStmtContext ctx) {
        AstNodes condition = visit(ctx.expr());
        List<AstNodes> body = visitStatementList(ctx.loopBody().statement());
        return new WhileLoop(condition, body);
    }

    // ── FOR loop ────────────────────────────────────────────────────────────

    @Override
    public AstNodes visitForStmt(FastFormulaParser.ForStmtContext ctx) {
        String variable = ctx.NAME().getText();
        AstNodes start = visit(ctx.expr(0));
        AstNodes end = visit(ctx.expr(1));
        List<AstNodes> body = visitStatementList(ctx.loopBody().statement());
        return new ForLoop(variable, start, end, body);
    }

    // ── CURSOR declaration ──────────────────────────────────────────────────

    @Override
    public AstNodes visitCursorDecl(FastFormulaParser.CursorDeclContext ctx) {
        String name = ctx.NAME().getText();
        var selectCtx = ctx.selectStmt();
        String tableName = selectCtx.NAME().getText();

        List<AstNodes> selectItems = new ArrayList<>();
        for (var itemCtx : selectCtx.selectItems().selectItem()) {
            selectItems.add(visit(itemCtx.expr()));
        }

        AstNodes whereClause = selectCtx.expr() != null ? visit(selectCtx.expr()) : null;
        return new CursorDecl(name, tableName, selectItems, whereClause);
    }

    // ── FOR cursor loop ─────────────────────────────────────────────────────

    @Override
    public AstNodes visitForCursorStmt(FastFormulaParser.ForCursorStmtContext ctx) {
        String variable = ctx.NAME(0).getText();
        String cursorName = ctx.NAME(1).getText();
        List<AstNodes> body = visitStatementList(ctx.loopBody().statement());
        return new ForCursorLoop(variable, cursorName, body);
    }

    // ── EXIT / EXIT WHEN ────────────────────────────────────────────────────

    @Override
    public AstNodes visitExitWhen(FastFormulaParser.ExitWhenContext ctx) {
        return new ExitStatement(visit(ctx.expr()));
    }

    @Override
    public AstNodes visitExitPlain(FastFormulaParser.ExitPlainContext ctx) {
        return new ExitStatement(null);
    }

    // ── Block statement ─────────────────────────────────────────────────────

    @Override
    public AstNodes visitBlockStmt(FastFormulaParser.BlockStmtContext ctx) {
        return new BlockGroup(visitStatementList(ctx.statement()));
    }

    @Override
    public AstNodes visitReturnWithValues(FastFormulaParser.ReturnWithValuesContext ctx) {
        List<String> variables = new ArrayList<>();
        for (var exprCtx : ctx.expr()) {
            AstNodes node = visit(exprCtx);
            if (node instanceof Identifier) {
                variables.add(((Identifier) node).name());
            }
        }
        return new ReturnStatement(variables);
    }

    @Override
    public AstNodes visitEmptyReturn(FastFormulaParser.EmptyReturnContext ctx) {
        return new ReturnStatement(List.of());
    }

    // ── Expressions ─────────────────────────────────────────────────────────

    @Override
    public AstNodes visitOrExpr(FastFormulaParser.OrExprContext ctx) {
        return new BinaryOp("OR", visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitAndExpr(FastFormulaParser.AndExprContext ctx) {
        return new BinaryOp("AND", visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitNotExpr(FastFormulaParser.NotExprContext ctx) {
        return new UnaryOp("NOT", visit(ctx.expr()));
    }

    @Override
    public AstNodes visitWasDefaulted(FastFormulaParser.WasDefaultedContext ctx) {
        return new WasDefaulted(visit(ctx.expr()).toString());
    }

    @Override
    public AstNodes visitWasNotDefaulted(FastFormulaParser.WasNotDefaultedContext ctx) {
        return new WasNotDefaulted(visit(ctx.expr()).toString());
    }

    @Override
    public AstNodes visitWasFound(FastFormulaParser.WasFoundContext ctx) {
        return new BinaryOp("WAS FOUND", visit(ctx.expr()), new NumberLiteral(1));
    }

    @Override
    public AstNodes visitWasNotFound(FastFormulaParser.WasNotFoundContext ctx) {
        return new UnaryOp("NOT", new BinaryOp("WAS FOUND", visit(ctx.expr()), new NumberLiteral(1)));
    }

    @Override
    public AstNodes visitIsNull(FastFormulaParser.IsNullContext ctx) {
        return new BinaryOp("IS NULL", visit(ctx.expr()), new NumberLiteral(0));
    }

    @Override
    public AstNodes visitIsNotNull(FastFormulaParser.IsNotNullContext ctx) {
        return new UnaryOp("NOT", new BinaryOp("IS NULL", visit(ctx.expr()), new NumberLiteral(0)));
    }

    @Override
    public AstNodes visitLikeExpr(FastFormulaParser.LikeExprContext ctx) {
        return new LikeExpr(visit(ctx.expr(0)), visit(ctx.expr(1)), false);
    }

    @Override
    public AstNodes visitNotLikeExpr(FastFormulaParser.NotLikeExprContext ctx) {
        return new LikeExpr(visit(ctx.expr(0)), visit(ctx.expr(1)), true);
    }

    @Override
    public AstNodes visitBetweenExpr(FastFormulaParser.BetweenExprContext ctx) {
        return new BetweenExpr(visit(ctx.expr(0)), visit(ctx.expr(1)), visit(ctx.expr(2)), false);
    }

    @Override
    public AstNodes visitNotBetweenExpr(FastFormulaParser.NotBetweenExprContext ctx) {
        return new BetweenExpr(visit(ctx.expr(0)), visit(ctx.expr(1)), visit(ctx.expr(2)), true);
    }

    @Override
    public AstNodes visitInExpr(FastFormulaParser.InExprContext ctx) {
        AstNodes value = visit(ctx.expr());
        List<AstNodes> items = visitExprListOrEmpty(ctx.exprList());
        return new InExpr(value, items, false);
    }

    @Override
    public AstNodes visitNotInExpr(FastFormulaParser.NotInExprContext ctx) {
        AstNodes value = visit(ctx.expr());
        List<AstNodes> items = visitExprListOrEmpty(ctx.exprList());
        return new InExpr(value, items, true);
    }

    @Override
    public AstNodes visitComparisonExpr(FastFormulaParser.ComparisonExprContext ctx) {
        String op = ctx.compOp().getText();
        return new BinaryOp(op, visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitConcatExpr(FastFormulaParser.ConcatExprContext ctx) {
        return new Concat(visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitAddExpr(FastFormulaParser.AddExprContext ctx) {
        String op = ctx.addOp().getText();
        return new BinaryOp(op, visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitMulExpr(FastFormulaParser.MulExprContext ctx) {
        String op = ctx.mulOp().getText();
        return new BinaryOp(op, visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    @Override
    public AstNodes visitNegExpr(FastFormulaParser.NegExprContext ctx) {
        return new UnaryOp("-", visit(ctx.expr()));
    }

    @Override
    public AstNodes visitAtomExpr(FastFormulaParser.AtomExprContext ctx) {
        return visit(ctx.atom());
    }

    // ── Atoms ───────────────────────────────────────────────────────────────

    @Override
    public AstNodes visitNumberLiteral(FastFormulaParser.NumberLiteralContext ctx) {
        return new NumberLiteral(Double.parseDouble(ctx.NUMBER().getText()));
    }

    @Override
    public AstNodes visitSingleStringLiteral(FastFormulaParser.SingleStringLiteralContext ctx) {
        String raw = ctx.SINGLE_STRING().getText();
        return new StringLiteral(raw.substring(1, raw.length() - 1).replace("''", "'"));
    }

    @Override
    public AstNodes visitTypedStringLiteral(FastFormulaParser.TypedStringLiteralContext ctx) {
        String raw = ctx.SINGLE_STRING().getText();
        return new TypedString(
                raw.substring(1, raw.length() - 1).replace("''", "'"),
                ctx.dataType().getText().replaceAll("[()]", "").toUpperCase()
        );
    }

    @Override
    public AstNodes visitMethodCall(FastFormulaParser.MethodCallContext ctx) {
        String object = ctx.NAME(0).getText();
        String method = ctx.NAME(1).getText();
        List<AstNodes> args = visitExprListOrEmpty(ctx.exprList());
        return new MethodCall(object, method, args);
    }

    @Override
    public AstNodes visitArrayAccess(FastFormulaParser.ArrayAccessContext ctx) {
        String name = ctx.NAME().getText();
        AstNodes index = visit(ctx.expr());
        return new ArrayAccess(name, index);
    }

    @Override
    public AstNodes visitFuncCall(FastFormulaParser.FuncCallContext ctx) {
        String name = ctx.NAME().getText();
        List<AstNodes> args = visitExprListOrEmpty(ctx.exprList());
        return new FunctionCall(name, args);
    }

    @Override
    public AstNodes visitVarRef(FastFormulaParser.VarRefContext ctx) {
        return new Identifier(ctx.NAME().getText());
    }

    @Override
    public AstNodes visitQuotedVarRef(FastFormulaParser.QuotedVarRefContext ctx) {
        String raw = ctx.QUOTED_NAME().getText();
        return new QuotedIdentifier(raw.substring(1, raw.length() - 1));
    }

    @Override
    public AstNodes visitParenExpr(FastFormulaParser.ParenExprContext ctx) {
        return visit(ctx.expr());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private List<AstNodes> visitStatementList(List<FastFormulaParser.StatementContext> stmts) {
        List<AstNodes> result = new ArrayList<>();
        for (var s : stmts) {
            result.add(visit(s));
        }
        return result;
    }

    private List<AstNodes> visitExprListOrEmpty(FastFormulaParser.ExprListContext ctx) {
        if (ctx == null) return List.of();
        List<AstNodes> result = new ArrayList<>();
        for (var exprCtx : ctx.expr()) {
            result.add(visit(exprCtx));
        }
        return result;
    }

    private static String stripQuotes(String s) {
        if (s.startsWith("'") && s.endsWith("'")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }
}
