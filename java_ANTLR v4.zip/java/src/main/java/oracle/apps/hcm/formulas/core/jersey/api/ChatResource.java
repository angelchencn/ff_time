package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.sse.Sse;
import jakarta.ws.rs.sse.SseEventSink;
import java.util.ArrayList;
import java.util.Map;

@Path("/chat")
public class ChatResource {

    private final AiService aiService = new AiService();
    private final ChatSessionStore sessionStore = ChatSessionStore.getInstance();
    private final CustomFormulaService customService = CustomFormulaService.getInstance();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void chat(Map<String, Object> request,
                     @Context SseEventSink eventSink,
                     @Context Sse sse) {
        String message = (String) request.get("message");
        String code = (String) request.getOrDefault("code", "");
        String formulaType = (String) request.getOrDefault("formula_type", "TIME_LABOR");
        String sessionId = (String) request.get("session_id");

        // Custom type: use selected sample as context, skip RAG
        String customSampleCode = null;
        if (customService.isCustomType(formulaType)) {
            // Use the sample the user selected in the dropdown (not the message text)
            String selectedSample = (String) request.get("selected_sample");
            if (selectedSample != null && !selectedSample.isBlank()) {
                var sample = customService.findSample(selectedSample);
                if (sample != null) {
                    customSampleCode = (String) sample.get("code");
                }
            }
            // Custom type always skips RAG — pass empty string if no sample matched
            if (customSampleCode == null) {
                customSampleCode = "";
            }
        }

        // Load or create chat session
        sessionId = sessionStore.getOrCreateSession(sessionId);
        var history = new ArrayList<>(sessionStore.getHistory(sessionId));

        StringBuilder fullResponse = new StringBuilder();

        aiService.streamChat(message, code, formulaType, history, customSampleCode, token -> {
            fullResponse.append(token);
            sendToken(eventSink, sse, token);
        });

        // Post-process: fix DEFAULT value types
        String response = fullResponse.toString();
        String fixed = AiService.fixDefaultTypes(response);
        if (!fixed.equals(response)) {
            try {
                eventSink.send(sse.newEventBuilder()
                        .name("message")
                        .data("{\"replace\":\"" + escapeJson(fixed) + "\"}")
                        .build()).toCompletableFuture().get();
            } catch (Exception ignored) {}
            response = fixed;
        }

        // Persist conversation turns
        sessionStore.addTurn(sessionId, "user", message);
        sessionStore.addTurn(sessionId, "assistant", response);

        sendDone(eventSink, sse);
    }

    private void sendToken(SseEventSink sink, Sse sse, String token) {
        if (sink.isClosed()) return;
        try {
            sink.send(sse.newEventBuilder()
                    .name("message")
                    .data("{\"text\":\"" + escapeJson(token) + "\"}")
                    .build()).toCompletableFuture().get();
        } catch (Exception ignored) {}
    }

    private void sendDone(SseEventSink sink, Sse sse) {
        if (sink.isClosed()) return;
        try {
            sink.send(sse.newEventBuilder()
                    .name("message")
                    .data("[DONE]")
                    .build());
            sink.close();
        } catch (Exception ignored) {}
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
