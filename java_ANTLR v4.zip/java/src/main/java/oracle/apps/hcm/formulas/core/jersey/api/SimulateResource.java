package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;

@Path("/simulate")
public class SimulateResource {

    private final SimulatorService simulatorService = new SimulatorService();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response simulate(Map<String, Object> request) {
        String code = (String) request.get("code");
        if (code == null || code.isBlank()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(Map.of("error", "code is required"))
                    .build();
        }

        @SuppressWarnings("unchecked")
        var inputs = (Map<String, Object>) request.getOrDefault("input_data", Map.of());
        var result = simulatorService.simulate(code, inputs);
        return Response.ok(result).build();
    }
}
