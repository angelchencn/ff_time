package oracle.apps.hcm.formulas.core.jersey.parser;

import oracle.apps.hcm.formulas.core.jersey.parser.AstNodes.*;
import groovyjarjarantlr4.v4.runtime.ANTLRInputStream;
import groovyjarjarantlr4.v4.runtime.CommonTokenStream;
import groovyjarjarantlr4.v4.runtime.BaseErrorListener;
import groovyjarjarantlr4.v4.runtime.RecognitionException;
import groovyjarjarantlr4.v4.runtime.Recognizer;

import java.util.ArrayList;
import java.util.List;

/**
 * Entry point for parsing Fast Formula source code.
 * Equivalent to Python's parse_formula() function.
 */
public class FFParser {

    public static final class ParseResult {
        private final Program program;
        private final List<Diagnostic> diagnostics;
        public ParseResult(Program program, List<Diagnostic> diagnostics) { this.program = program; this.diagnostics = diagnostics; }
        public Program program() { return program; }
        public List<Diagnostic> diagnostics() { return diagnostics; }
    }

    public static final class Diagnostic {
        private final int line;
        private final int col;
        private final String severity;
        private final String message;
        public Diagnostic(int line, int col, String severity, String message) {
            this.line = line; this.col = col; this.severity = severity; this.message = message;
        }
        public int line() { return line; }
        public int col() { return col; }
        public String severity() { return severity; }
        public String message() { return message; }
    }

    /**
     * Parse Fast Formula source code into an AST.
     *
     * @param code the formula source code
     * @return ParseResult with program (if successful) and any diagnostics
     */
    public static ParseResult parse(String code) {
        List<Diagnostic> diagnostics = new ArrayList<>();

        var charStream = new ANTLRInputStream(code);
        var lexer = new FastFormulaLexer(charStream);
        var tokens = new CommonTokenStream(lexer);
        var parser = new FastFormulaParser(tokens);

        // Collect syntax errors
        parser.removeErrorListeners();
        parser.addErrorListener(new BaseErrorListener() {
            @Override
            public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                    int line, int charPositionInLine,
                                    String msg, RecognitionException e) {
                diagnostics.add(new Diagnostic(line, charPositionInLine + 1, "error", msg));
            }
        });

        var tree = parser.program();

        if (!diagnostics.isEmpty()) {
            return new ParseResult(null, diagnostics);
        }

        var builder = new FastFormulaAstBuilder();
        var program = (Program) builder.visit(tree);
        return new ParseResult(program, List.of());
    }
}
