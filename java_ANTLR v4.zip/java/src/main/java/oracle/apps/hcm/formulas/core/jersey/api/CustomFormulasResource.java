package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;

@Path("/custom-formulas")
public class CustomFormulasResource {

    private final CustomFormulaService service = CustomFormulaService.getInstance();

    /** List all custom formula samples */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response listSamples() {
        return Response.ok(service.getAllSamples()).build();
    }

    /** Get a specific sample by name */
    @GET
    @Path("/{name}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSample(@PathParam("name") String name) {
        var sample = service.findSample(name);
        if (sample == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity(Map.of("error", "Sample not found: " + name))
                    .build();
        }
        return Response.ok(sample).build();
    }

    /** Replace all custom formula samples */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSamples(List<Map<String, Object>> samples) {
        service.replaceSamples(samples);
        return Response.ok(Map.of("status", "saved", "count", samples.size())).build();
    }
}
