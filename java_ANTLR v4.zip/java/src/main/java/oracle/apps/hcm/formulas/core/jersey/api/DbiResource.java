package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/dbi")
public class DbiResource {

    private final DbiService dbiService = new DbiService();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDbis(@QueryParam("module") String module,
                            @QueryParam("search") String search,
                            @QueryParam("data_type") String dataType,
                            @QueryParam("limit") Integer limit,
                            @QueryParam("offset") Integer offset) {
        int lim = limit != null ? limit : 500;
        int off = offset != null ? offset : 0;
        var result = dbiService.getDbis(module, search, dataType, lim, off);
        return Response.ok(result).build();
    }

    @GET
    @Path("/modules")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModules() {
        return Response.ok(dbiService.getModules()).build();
    }
}
