package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;

@Path("/formula-types")
public class FormulaTypesResource {

    private final FormulaTypesService service = new FormulaTypesService();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response listFormulaTypes() {
        return Response.ok(service.listAll()).build();
    }

    @GET
    @Path("/{typeName}/template")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTemplate(@PathParam("typeName") String typeName) {
        var template = service.getTemplate(typeName);
        if (template == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity(Map.of("error", "Unknown formula type: " + typeName))
                    .build();
        }
        return Response.ok(template).build();
    }
}
