package oracle.apps.hcm.formulas.core.jersey.api;

import oracle.apps.hcm.formulas.core.jersey.service.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.sse.Sse;
import jakarta.ws.rs.sse.SseEventSink;
import java.util.Map;

@Path("/explain")
public class ExplainResource {

    private final AiService aiService = new AiService();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void explain(Map<String, Object> request,
                        @Context SseEventSink eventSink,
                        @Context Sse sse) {
        String code = (String) request.getOrDefault("code", "");

        aiService.streamExplain(code, token -> {
            try {
                eventSink.send(sse.newEventBuilder()
                        .name("message")
                        .data("{\"text\":\"" + escapeJson(token) + "\"}")
                        .build()).toCompletableFuture().get();
            } catch (Exception ignored) {}
        });

        eventSink.send(sse.newEventBuilder()
                .name("message")
                .data("[DONE]")
                .build());
        eventSink.close();
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
