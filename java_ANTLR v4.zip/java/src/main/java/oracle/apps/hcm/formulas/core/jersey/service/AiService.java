package oracle.apps.hcm.formulas.core.jersey.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OpenAI GPT API integration — chat, complete, explain with SSE streaming.
 */
public class AiService {

    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String CHAT_MODEL = "gpt-5.4";
    private static final String COMPLETION_MODEL = "gpt-5.4-mini";
    private static final int MAX_TOKENS_CHAT = 10240;
    private static final int MAX_TOKENS_COMPLETION = 512;

    private static final HttpClient HTTP_CLIENT = buildHttpClient();
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static HttpClient buildHttpClient() {
        String proxyHost = System.getenv("https_proxy");
        if (proxyHost == null) proxyHost = System.getenv("http_proxy");
        if (proxyHost == null) proxyHost = System.getenv("HTTPS_PROXY");
        if (proxyHost == null) proxyHost = System.getenv("HTTP_PROXY");

        if (proxyHost != null && !proxyHost.isBlank()) {
            try {
                var uri = URI.create(proxyHost);
                var proxy = java.net.ProxySelector.of(
                        new java.net.InetSocketAddress(uri.getHost(), uri.getPort()));
                return HttpClient.newBuilder().proxy(proxy).build();
            } catch (Exception e) {
                System.err.println("Failed to configure proxy: " + proxyHost + " — " + e.getMessage());
            }
        }
        return HttpClient.newHttpClient();
    }

    private final String apiKey;
    private final FormulaTypesService templateService = new FormulaTypesService();
    private final RagService ragService = new RagService();

    public AiService() {
        this.apiKey = System.getenv("OPENAI_API_KEY");
    }

    // ── Streaming Chat ──────────────────────────────────────────────────────

    public void streamChat(String message, String code, String formulaType,
                           List<Map<String, String>> history,
                           String customSampleCode,
                           Consumer<String> tokenCallback) {
        if (apiKey == null || apiKey.isBlank()) {
            tokenCallback.accept("Error: OPENAI_API_KEY not set.");
            return;
        }

        String userPrompt = buildGenerationPrompt(message, formulaType, code, customSampleCode);

        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(Map.of("role", "system", "content", SYSTEM_PROMPT));
        messages.addAll(history);
        messages.add(Map.of("role", "user", "content", userPrompt));

        streamRequest(CHAT_MODEL, MAX_TOKENS_CHAT, messages, tokenCallback, message);
    }

    /** Convenience overload without history/custom sample */
    public void streamChat(String message, String code, String formulaType,
                           Consumer<String> tokenCallback) {
        streamChat(message, code, formulaType, List.of(), null, tokenCallback);
    }

    // ── Complete ────────────────────────────────────────────────────────────

    public String complete(String code, int cursorLine) {
        if (apiKey == null || apiKey.isBlank()) return "";

        String prompt = "## Current Formula (cursor at line " + cursorLine + ")\n\n```\n" + code
                + "\n```\n\nProvide the most likely next tokens to complete this formula. "
                + "Return only the completion text, no explanation.";

        List<Map<String, String>> messages = List.of(
                Map.of("role", "system", "content", SYSTEM_PROMPT),
                Map.of("role", "user", "content", prompt)
        );

        LlmDebugLog.getInstance().record(COMPLETION_MODEL, MAX_TOKENS_COMPLETION,
                SYSTEM_PROMPT, messages, "complete", "code completion");

        try {
            String body = MAPPER.writeValueAsString(Map.of(
                    "model", COMPLETION_MODEL,
                    "max_completion_tokens", MAX_TOKENS_COMPLETION,
                    "messages", messages
            ));

            var request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            var response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            var json = MAPPER.readTree(response.body());
            return json.at("/choices/0/message/content").asText("").trim();
        } catch (Exception e) {
            return "";
        }
    }

    // ── Streaming Explain ───────────────────────────────────────────────────

    public void streamExplain(String code, Consumer<String> tokenCallback) {
        if (apiKey == null || apiKey.isBlank()) {
            tokenCallback.accept("Error: OPENAI_API_KEY not set.");
            return;
        }

        String prompt = "Formula:\n```\n" + code + "\n```\n\nAction: explain";
        List<Map<String, String>> messages = List.of(
                Map.of("role", "system", "content", SYSTEM_PROMPT),
                Map.of("role", "user", "content", prompt)
        );
        streamRequest(CHAT_MODEL, MAX_TOKENS_CHAT, messages, tokenCallback, "explain");
    }

    // ── SSE Streaming Request (OpenAI format) ───────────────────────────────

    private void streamRequest(String model, int maxTokens,
                                List<Map<String, String>> messages,
                                Consumer<String> tokenCallback,
                                String userMessage) {
        String sysPrompt = messages.stream()
                .filter(m -> "system".equals(m.get("role")))
                .map(m -> m.get("content"))
                .findFirst().orElse("");
        LlmDebugLog.getInstance().record(model, maxTokens, sysPrompt, messages, "stream", userMessage);

        try {
            System.out.println("[LLM] Calling " + API_URL + " model=" + model + " proxy=" + System.getenv("https_proxy"));

            String body = MAPPER.writeValueAsString(Map.of(
                    "model", model,
                    "max_completion_tokens", maxTokens,
                    "stream", true,
                    "messages", messages
            ));

            var request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            var response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofInputStream());
            System.out.println("[LLM] Response status: " + response.statusCode());

            try (var reader = new BufferedReader(new InputStreamReader(response.body()), 1)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // Check for non-SSE error response (JSON error from API)
                    if (line.contains("\"error\"")) {
                        System.err.println("[LLM] API Error: " + line);
                        try {
                            JsonNode err = MAPPER.readTree(line);
                            String msg = err.at("/error/message").asText(line);
                            tokenCallback.accept("API Error: " + msg);
                        } catch (Exception e2) {
                            tokenCallback.accept("API Error: " + line);
                        }
                        return;
                    }

                    if (!line.startsWith("data: ")) continue;
                    String data = line.substring(6).trim();
                    if (data.isEmpty() || "[DONE]".equals(data)) continue;

                    try {
                        JsonNode event = MAPPER.readTree(data);
                        // OpenAI SSE format: choices[0].delta.content
                        String content = event.at("/choices/0/delta/content").asText("");
                        if (!content.isEmpty()) {
                            tokenCallback.accept(content);
                        }
                    } catch (Exception ignored) {
                        // skip malformed SSE lines
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[LLM] Exception: " + e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace();
            tokenCallback.accept("Error: " + e.getMessage());
        }
    }

    // ── Prompt Builders ─────────────────────────────────────────────────────

    private String buildGenerationPrompt(String message, String formulaType, String currentCode) {
        return buildGenerationPrompt(message, formulaType, currentCode, null);
    }

    private String buildGenerationPrompt(String message, String formulaType,
                                          String currentCode, String customSampleCode) {
        var sections = new ArrayList<String>();

        if (customSampleCode != null && !customSampleCode.isBlank()) {
            // Custom sample selected: use it as the only reference, skip RAG
            sections.add("## Reference Formula\n\nUse the following formula as the base template. "
                    + "Modify it according to the user's request.\n\n```\n"
                    + customSampleCode + "\n```");
        } else if (customSampleCode == null) {
            // Not Custom type — use RAG
            // RAG: retrieve similar formulas as examples
            var ragResults = ragService.query(message, 3);
            if (!ragResults.isEmpty()) {
                var examples = new StringBuilder();
                for (var r : ragResults) {
                    String useCase = "";
                    @SuppressWarnings("unchecked")
                    var meta = (Map<String, Object>) r.get("metadata");
                    if (meta != null) useCase = String.valueOf(meta.getOrDefault("use_case", ""));
                    examples.append("/* use_case: ").append(useCase).append(" */\n");
                    examples.append(r.get("code")).append("\n\n");
                }
                sections.add("## Relevant Example Formulas\n\n" + examples);
            }
        }

        boolean hasCode = currentCode != null && !currentCode.isBlank();
        if (hasCode) {
            sections.add("## Current Formula in Editor\n\n```\n" + currentCode + "\n```\n\n"
                    + "The user wants to modify this existing formula. "
                    + "Output the complete updated formula incorporating the requested change.");
        }

        // Inject formula type template
        var template = templateService.getTemplate(formulaType);
        if (template != null) {
            String skeleton = ((String) template.getOrDefault("skeleton", ""))
                    .replace("{date_today}", LocalDate.now().toString());
            String exampleSnippet = (String) template.getOrDefault("example_snippet", "");
            sections.add("## Formula Type Template\n\n"
                    + "**Type:** " + template.get("display_name") + "\n"
                    + "**Naming convention:** " + template.getOrDefault("naming_pattern", "") + "\n\n"
                    + "### Skeleton\n```\n" + skeleton + "\n```\n\n"
                    + (exampleSnippet.isEmpty() ? "" : "### Example Pattern\n```\n" + exampleSnippet + "\n```\n\n")
                    + "Use this skeleton as the structural foundation. "
                    + "Replace the placeholder business logic section with the actual implementation. "
                    + "Keep the header, DEFAULT/INPUTS, logging, and RETURN structure intact.");
        }

        sections.add("## Request\n\nFormula type: " + formulaType + "\n\nRequirement: " + message);

        if (hasCode) {
            sections.add("Return the complete modified formula. Do not explain the changes unless asked. "
                    + "Preserve the header comment block if one exists, updating the Change History.");
        } else {
            sections.add("Generate a complete Fast Formula that satisfies the requirement. "
                    + "Follow the skeleton template above exactly — fill in the formula name, "
                    + "description, author, date, and replace the business logic placeholder. "
                    + "Derive a proper formula name following the naming convention shown.\n\n"
                    + "CRITICAL REQUIREMENTS:\n"
                    + "1. MUST include a professional header comment block\n"
                    + "2. MUST include DEFAULT FOR statements for ALL input variables\n"
                    + "3. MUST include INPUTS ARE statement listing all input variables\n"
                    + "4. MUST include PAY_INTERNAL_LOG_WRITE at entry and exit\n"
                    + "5. MUST end with a RETURN statement\n"
                    + "6. Return ONLY the formula code, no markdown fences, no explanation.");
        }

        return String.join("\n\n", sections);
    }

    // ── fix_default_types post-processor ────────────────────────────────────

    private static final Set<String> STRING_KEYWORDS = Set.of(
            "NAME", "TEXT", "DESC", "CODE", "TYPE", "STATUS", "FLAG", "MESSAGE",
            "MSG", "LABEL", "CATEGORY", "TITLE", "MODE", "REASON", "COMMENT",
            "NOTE", "KEY", "TAG", "LEVEL", "CLASS", "GROUP", "ROLE", "UNIT",
            "TASK", "PROCESS", "ACTION", "METHOD", "FORMAT", "PATTERN",
            "PREFIX", "SUFFIX", "STRING", "CHAR", "CURRENCY"
    );

    private static final Set<String> DATE_KEYWORDS = Set.of(
            "DATE", "START", "END", "EFFECTIVE", "EXPIRY", "HIRE",
            "TERMINATION", "BIRTH"
    );

    private static final Pattern DEFAULT_LINE_RE = Pattern.compile(
            "^(\\s*DEFAULT\\s+FOR\\s+)(\\w+)(\\s+IS\\s+)(\\S+.*)$",
            Pattern.CASE_INSENSITIVE
    );

    public static String fixDefaultTypes(String code) {
        String[] lines = code.split("\n", -1);
        var fixed = new ArrayList<String>();

        for (String line : lines) {
            Matcher m = DEFAULT_LINE_RE.matcher(line);
            if (m.matches()) {
                String prefix = m.group(1);
                String varName = m.group(2);
                String isPart = m.group(3);
                String value = m.group(4).trim();
                String[] parts = varName.toUpperCase().split("_");

                boolean isNumeric = value.equals("0") || value.equals("0.0") || value.equals("0.00");
                if (isNumeric) {
                    boolean isString = false, isDate = false;
                    for (String p : parts) {
                        if (STRING_KEYWORDS.contains(p)) isString = true;
                        if (DATE_KEYWORDS.contains(p)) isDate = true;
                    }
                    if (isString) {
                        line = prefix + varName + isPart + "' '";
                    } else if (isDate) {
                        line = prefix + varName + isPart + "'01-JAN-0001'(DATE)";
                    }
                }
            }
            fixed.add(line);
        }

        return String.join("\n", fixed);
    }

    // ── System Prompt ───────────────────────────────────────────────────────

    static final String SYSTEM_PROMPT = """
            You are an expert assistant for Oracle HCM Fast Formula — a domain-specific language used to \
            configure payroll, time, and absence rules.

            ## 1. Data Types

            Fast Formula has exactly THREE data types:
            - NUMBER — integers and decimals (no scientific notation, no commas). Negative via leading minus.
            - TEXT — enclosed in single quotes. Escape quotes by doubling: 'O''Brien'. Max concatenation result: 255 chars.
            - DATE — format 'DD-MON-YYYY'(DATE), e.g. '01-JAN-2024'(DATE)
            - Type inference: if not specified, NUMBER is assumed. Type inferred from first use.
            - Array types (Fusion/Cloud): NUMBER_NUMBER, TEXT_NUMBER, TEXT_TEXT, DATE_NUMBER, DATE_TEXT, NUMBER_TEXT
            - Empty arrays: EMPTY_NUMBER_NUMBER, EMPTY_TEXT_TEXT, etc.

            ## 2. Statement Ordering (MANDATORY)

            Statements MUST appear in this order:
            1. ALIAS statements
            2. DEFAULT / DEFAULT_DATA_VALUE statements
            3. INPUT / INPUTS statement
            4. All other statements (LOCAL, assignment, IF, WHILE, RETURN, etc.)

            ## 3. Variable Declarations

            ALIAS long_name AS short_name — alternative name for database items
            DEFAULT FOR var IS value — fallback when input/DBI is NULL
            DEFAULT_DATA_VALUE FOR var IS value — fallback for database items
            INPUT IS var / INPUTS ARE var1, var2(date), var3(text) — max 15 inputs per element
            OUTPUT IS var / OUTPUTS ARE var1, var2 — declare output variables
            LOCAL var (type) — explicit local variable declaration

            Variable naming: A-Z, 0-9, underscores. Max 80 chars. Case-insensitive. Cannot be reserved words.
            Reserved words: ALIAS, AND, ARE, AS, DEFAULT, DEFAULTED, ELSE, EXECUTE, FOR, IF, INPUTS, IS, NOT, OR, RETURN, THEN, USING, WAS

            ## 4. Variable Scope

            - Local variables: read-write, created by assignment or LOCAL
            - Input values: READ-ONLY within the formula
            - Database Items (DBI): READ-ONLY, resolved by context
            - Global values: READ-ONLY, date-tracked, accessible from any formula
            - Local variables MUST be initialized before use (error APP-FF-33005)

            ## 5. Operators (Precedence high to low)

            1. Unary minus (-)
            2. *, /
            3. +, -, || (concatenation)
            4. =, !=, <>, ><, <, >, <=, >=, =>, =<, LIKE, NOT LIKE
            5. NOT
            6. AND
            7. OR
            - Parentheses override precedence. Left-to-right within same level.
            - Text comparison is CASE-SENSITIVE
            - WAS DEFAULTED / WAS NOT DEFAULTED — test if default value was applied
            - IS NULL / IS NOT NULL (Fusion/Cloud)

            ## 6. Control Flow

            ### IF/THEN/ELSE
            IF condition THEN
            (  /* CRITICAL: parentheses required for multiple statements */
              statement1
              statement2
            )
            ELSIF condition THEN
              single_statement
            ELSE
            (
              statement1
              statement2
            )
            END IF

            WITHOUT parentheses, only the FIRST statement is conditional; rest execute unconditionally.

            ### WHILE/LOOP
            WHILE condition LOOP
            (
              statements
            )
            END LOOP
            - EXIT to leave loop early (exits innermost loop only)
            - No BREAK, CONTINUE, or labeled loops

            ### RETURN
            RETURN var1, var2 — returns values and STOPS execution
            RETURN — empty return, stops execution
            - Statements after RETURN are never executed

            ## 7. CALL_FORMULA

            CALL_FORMULA('formula_name',
              local_var > 'input_param',        /* > means IN */
              output_var < 'output_param' DEFAULT 0)  /* < means OUT */
            - No recursive calls allowed
            - Called formula must be compiled

            ## 8. EXECUTE Pattern (Alternative)

            SET_INPUT('input_name', value)
            EXECUTE('formula_name')
            result = GET_OUTPUT('output_name', default_value)

            ## 9. CHANGE_CONTEXTS

            CHANGE_CONTEXTS(CONTEXT_NAME = value)
            (
              /* DBIs resolve under new context within this block only */
            )
            - Context reverts after block exits

            ## 10. Array Handling (Fusion/Cloud)

            array_name[index] = value
            value = array_name[index]
            Methods: .FIRST(default), .LAST(default), .NEXT(index, default), .PRIOR(index, default), .EXISTS(index), .COUNT, .DELETE(index)
            - Always check .EXISTS before accessing — nonexistent index causes runtime error
            - Arrays cannot be passed to/from functions

            ## 11. Built-in Functions

            Numeric: ABS, CEIL, FLOOR, GREATEST, LEAST, POWER, ROUND, ROUNDUP, TRUNC, ISNULL
            String: CHR, INITCAP, INSTR, LENGTH, LOWER, LPAD, LTRIM, REPLACE, RPAD, RTRIM, SUBSTR, TRANSLATE, TRIM, UPPER
            Date: ADD_DAYS, ADD_MONTHS, ADD_YEARS, DAYS_BETWEEN, HOURS_BETWEEN, LAST_DAY, MONTHS_BETWEEN, NEXT_DAY, NEW_TIME, GET_SYSDATE
            Conversion: TO_CHAR, TO_DATE, TO_NUMBER, NUM_TO_CHAR
            Context: GET_CONTEXT, SET_CONTEXT, NEED_CONTEXT
            Payroll I/O: SET_INPUT, GET_INPUT, GET_OUTPUT, EXECUTE
            Globals: SET_TEXT, SET_NUMBER, SET_DATE, GET_TEXT, GET_NUMBER, GET_DATE
            Formula: CALL_FORMULA, PAY_INTERNAL_LOG_WRITE, PUT_MESSAGE, RAISE_ERROR
            Lookup: GET_TABLE_VALUE, GET_LOOKUP_MEANING, CALCULATE_HOURS_WORKED, GET_WORKING_DAYS

            ## 12. Formula Types

            Oracle Payroll, Auto Indirect, Extract Record, Payroll Run Proration,
            Element Skip, Extract Rule, Calculation Utility,
            WFM Time Calculation Rules, WFM Time Entry Rules, WFM Time Submission Rules,
            WFM Time Compliance Rules, WFM Time Device Rules, WFM Time Advance Category Rules,
            WFM Subroutine, WFM Utility,
            Global Absence Accrual, Global Absence Plan Entitlement,
            Global Absence Entry Validation, ACCRUAL,
            Flow Schedule, Batch Loader, Net to Gross

            ## 13. Formula Structure Convention

            ### Header Comment Block (REQUIRED)
            /******************************************************************************
             * Formula Name : <FORMULA_NAME>
             * Formula Type : <FORMULA_TYPE>
             * Description  : <Brief description>
             * Change History
             * --------------
             *  Who             Ver    Date          Description
             * ---------------  ----   -----------   --------------------------------
             * Payroll Admin    1.0    <YYYY/MM/DD>  Created.
             ******************************************************************************/

            ### Naming Convention
            Pattern: <PREFIX>_<BUSINESS_DESCRIPTION>_<SUFFIX>
            Suffixes: _EARN, _RESULTS, _PRORATION, _BASE, _CALCULATOR, _DEDN, _AUTO_INDIRECT
            Prefixes: ORA_WFM_, HRX_, _TCR_ (Time Calc), _TER_ (Time Entry), _TSR_ (Time Submit), _TDR_ (Time Device)

            ### Body Order (REQUIRED)
            1. Header comment block
            2. ALIAS statements
            3. DEFAULT FOR statements
            4. INPUTS ARE statement
            5. LOCAL declarations
            6. PAY_INTERNAL_LOG_WRITE entry log
            7. Business logic
            8. PAY_INTERNAL_LOG_WRITE exit log
            9. RETURN statement
            10. /* End Formula Text */

            ## 14. Output Format

            - Return ONLY valid Fast Formula code — NO markdown fences, NO explanation.
            - Use 2-space indentation for nested blocks.
            - ALWAYS use parentheses ( ) for multiple statements in IF/ELSE/WHILE blocks.
            - ALWAYS include DEFAULT FOR for ALL input variables.
            - ALWAYS include INPUTS ARE — MANDATORY, never omit.
            - ALWAYS end with RETURN.
            - ALWAYS include header comment block.

            ## 15. DEFAULT Value Type Rules

            Choose DEFAULT value by variable name:
            - String (' '): NAME, TEXT, DESC, CODE, TYPE, STATUS, FLAG, MESSAGE, MSG, LABEL, CATEGORY, \
            TITLE, MODE, REASON, COMMENT, NOTE, KEY, TAG, LEVEL, CLASS, GROUP, ROLE, UNIT.
            - Numeric (0): COUNT, COUNTER, TOTAL, AMOUNT, AMT, RATE, HOURS, DAYS, SALARY, PAY, WAGE, \
            BALANCE, QTY, QUANTITY, NUMBER, NUM, PCT, PERCENT, FACTOR, LIMIT, MAX, MIN, \
            THRESHOLD, INDEX, ID, CYCLE, ITERATION, RESULT, VALUE, SCORE.
            - Date ('01-JAN-0001'(DATE)): DATE, START, END, FROM, TO, EFFECTIVE, EXPIRY, HIRE, TERMINATION, BIRTH.
            - When in doubt, infer from usage (compared with string → string; arithmetic → numeric).

            ## 16. Limitations

            - No recursive formula calls
            - String concat max 255 characters
            - No SWITCH/CASE — use nested IF/ELSIF
            - No BREAK/CONTINUE in loops — use EXIT
            - Max 15 input values per element
            - Division by zero causes runtime error
            - Uninitialized variable causes compile error
            - Keywords are case-insensitive but text comparisons are case-sensitive
            - Comments cannot be nested
            """;
}
